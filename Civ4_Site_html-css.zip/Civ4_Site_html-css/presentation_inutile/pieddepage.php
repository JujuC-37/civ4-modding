<footer>
	<p>Contact : Créatrice</a></p>
	<p class="basitalique">Les exemples ne reflètent en rien les idées de la créatrice.</p>
</footer>