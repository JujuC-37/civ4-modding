﻿<nav>
	<ul>
		<li><img src="images/M_accueil.png" alt="accueil"> <a href="index.php" class="blanc_non_souligne">Accueil</a></li>
		<li><img src="images/M_menu.png" alt="menu"> <a href="creer_ecran.php" class="blanc_non_souligne">Changer le fond de l'écran d'accueil</a></li>
		<li><img src="images/M_musique.png" alt="musique"> <a href="creer_musique.php" class="blanc_non_souligne">Changer la musique</a></li>
		<li><img src="images/M_heros.png" alt="héros"> <a href="creer_heros.php" class="blanc_non_souligne">Créer un héros</a></li>
		<li><img src="images/M_civilisation.png" alt="civilisation"> <a href="creer_civilisation.php" class="blanc_non_souligne">Créer une civilisation</a></li>
		<li><img src="images/M_trait.png" alt="trait"> <a href="creer_trait.php" class="blanc_non_souligne">Créer un trait</a></li>
		<li><img src="images/M_unite.png" alt="unité"> <a href="creer_unite.php" class="blanc_non_souligne">Créer une unité</a></li>
		<li><img src="images/M_batiment.png" alt="bâtiment"> <a href="creer_batiment.php" class="blanc_non_souligne">Créer un bâtiment</a></li>
		<li><img src="images/M_tech.png" alt="tech"> <a href="creer_technologie.php" class="blanc_non_souligne">Créer une technologie</a></li>
		<li><img src="images/M_ressource.png" alt="ressource"> <a href="creer_ressource.php" class="blanc_non_souligne">Créer une ressource</a></li>
		<li><img src="images/M_doctrine.png" alt="doctrine"> <a href="creer_doctrine.php" class="blanc_non_souligne">Créer une doctrine</a></li>
		<li><img src="images/M_promotion.png" alt="promotion"> <a href="creer_promotion.php" class="blanc_non_souligne">Créer une promotion</a></li>
		<li><img src="images/M_religion.png" alt="religion"> <a href="creer_religion.php" class="blanc_non_souligne">Créer une religion</a></li>
		<li><img src="images/M_corporation.png" alt="société commerciale"> <a href="creer_societe_commerciale.php" class="blanc_non_souligne">Créer une société commerciale</a></li>
		<li><img src="images/M_carte.png" alt="carte"> <a href="creer_carte.php" class="blanc_non_souligne">Créer une carte</a></li>
		<li><img src="images/M_annexes.png" alt="annexes"> <a href="annexes.php" class="blanc_non_souligne">Annexes</a></li>
		<li><img src="images/M_credits_images.png" alt="crédits"> <a href="credits_images.php" class="blanc_non_souligne">Crédits et images</a></li>
	</ul>
</nav>
<div id="fleche">
	<a href="#header"><img src="images/fleche.png"></a>
</div>